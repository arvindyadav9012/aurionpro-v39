AurionPro Android V39

Changes in V39:
1. Location permission/WebView geolocation support retained and strengthened.
2. Full navigation menu is rendered; report screens still enforce their permission checks.
3. Login session is restored from localStorage after reload; duplicate login script was removed so refresh does not force logout.

Build in Android Studio:
- Open the aurion_android_v38 folder as the project.
- Let Gradle sync complete.
- Build > Build Bundle(s) / APK(s) > Build APK(s).
- APK output: app/build/outputs/apk/debug/app-debug.apk (debug build).


V39 COMPLETE: Gradle launcher included. GitHub Actions can build with ./gradlew assembleDebug.
