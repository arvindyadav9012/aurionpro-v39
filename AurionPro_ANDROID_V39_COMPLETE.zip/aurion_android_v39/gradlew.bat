@echo off
set GRADLE_VERSION=8.7
set DIST=%USERPROFILE%\.gradle\wrapper\dists\aurion-gradle-%GRADLE_VERSION%\gradle-%GRADLE_VERSION\bin\gradle.bat
if exist "%DIST%" goto run
echo Please use GitHub Actions build workflow for mobile build.
exit /b 1
:run
call "%DIST%" %*
